#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 18 21:25:12 2020

@author: Ozan
"""

import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QGridLayout, QWidget,\
    QPushButton, QTextEdit, QFileDialog,QAction, QToolBar, QTabWidget, QHBoxLayout,\
    QMessageBox, QTableWidgetItem, QLabel, QLineEdit, QHeaderView, QDialog,\
    QFrame, QScrollArea, QVBoxLayout, QStatusBar, QStackedLayout, QTableWidget,\
    QComboBox, QShortcut
from PyQt5.QtCore import QCoreApplication, QSize, Qt
from PyQt5.QtGui import QIcon, QKeySequence, QIntValidator, QPixmap, QPalette,\
    QBrush
import os
import os.path
import pathlib
import shutil
from shutil import copyfile
import time
import zipfile
import rarfile
from pathlib import Path
import ast
import webbrowser


# FENÊTRE PRINCIPALE :

class FenetrePrincipale(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Liseuse de Bandes Dessinées")

# Obtention des dimensions de l'écran utilisé et mise en place de la fenêtre en fonction :

        screen = app.primaryScreen()
        rect = screen.availableGeometry()
        self.left = 10
        self.top = 10
        self.width = rect.width()
        self.height = rect.height()*0.9749
        self.setGeometry(self.left, self.top, self.width, self.height)

        self.filedir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/temp"
        self.permfiledir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/perm"

# Message de première ouverture :

        if not os.path.exists(self.permfiledir):
            firstTimeMsg = QMessageBox()
            firstTimeMsg.setIcon(QMessageBox.Information)
            firstTimeMsg.setText("Première ouverture :")
            firstTimeMsg.setInformativeText("Bienvenue sur la visionneuse de Bandes Dessinées !\
\n\nOuvrez votre première Bande Dessinée au format .cbz (Ctrl+O) pour commencer à utiliser le programme.\
\n\nSi vous avez besoin d'aide, appuyez sur le bouton '?'.")
            firstTimeMsg.setWindowTitle("Visionneuse de BD")
            firstTimeMsg.exec_()

        self.toolbar = QToolBar("Toolbar")

        self.layout = QGridLayout()
        self.setCentralWidget(QWidget(self))
        self.centralWidget().setLayout(self.layout)
        self.move(0, 0)
        self.setIconSize(QSize(16, 16))
        self.addToolBar(self.toolbar)

        self.tabs_widget = TabsWidget(self)

# Boutons de la barre des tâches et barre d'outils:

# Bouton "Ouvrir" :

        self.ouvrir = QAction(QIcon("icons/open.png"), "Ouvrir", self)
        self.ouvrir.setStatusTip("Ouvrir une Bande Dessinée")
        self.ouvrir.setShortcut(QKeySequence("Ctrl+O"))
        self.ouvrir.setToolTip("Ouvrir une Bande Dessinée")
        self.ouvrir.triggered.connect(self.tabs_widget.Ouvrir)

# Bouton "Bibliothèque" :

        self.biblio = QAction(QIcon("icons/library.png"), "Bibliothèque", self)
        self.biblio.setStatusTip("Ma bibliothèque de Bandes Dessinées.")
        self.biblio.setShortcut(QKeySequence("Ctrl+L"))
        self.biblio.setToolTip("Ouvrir la bibliothèque de bandes dessinées")
        self.biblio.triggered.connect(self.tabs_widget.Biblio)

# Bouton "Quitter" :

        self.quit = QAction(QIcon("icons/quit.png"), "Quițter")
        self.quit.setStatusTip("Quitter le logiciel")
        self.quit.setShortcut(QKeySequence("Ctrl+Q"))
        self.quit.triggered.connect(self.closeEvent)

# Bouton "Notice" :

        self.help = QAction(QIcon("icons/help.png"), "Notice")
        self.help.setStatusTip("Obtenir de l'aide")
        self.help.setShortcut(QKeySequence("Ctrl+N"))
        self.help.setToolTip("Obtenir de l'aide")
        self.help.triggered.connect(self.Aide)

# Bouton "Partager sur Twitter" :

        self.shareTweet = QAction(QIcon("icons/twitter.png"), "Twitter")
        self.shareTweet.setStatusTip("Partager sur Twitter")
        self.shareTweet.setShortcut(QKeySequence("Ctrl+shift+T"))
        self.shareTweet.setToolTip("Partager sur Twitter")
        self.shareTweet.triggered.connect(self.shareTwitter)

# Bouton "Partager sur Facebook" :

        self.shareFace = QAction(QIcon("icons/facebook.png"), "Facebook")
        self.shareFace.setStatusTip("Poster un statut Facebook")
        self.shareFace.setShortcut(QKeySequence("Ctrl+shift+F"))
        self.shareFace.setToolTip("Poster un statut Facebook")
        self.shareFace.triggered.connect(self.shareFacebook)

# Bouton "Supprimer une bande dessinée sauvegardée" :

        self.deleteButton = QAction(QIcon("icons/delet.png"), "Supprimer une BD")
        self.deleteButton.setShortcut(QKeySequence("Ctrl+shift+S"))
        self.deleteButton.setToolTip("Supprimer une Bande Dessinée sauvegardée")
        self.deleteButton.triggered.connect(self.plsDELET)

# Bouton "Rénitialiser les données de l'application" :

        self.reinitButton = QAction(QIcon("icons/eraser.png"), "Réinitialiser l'application")
        self.reinitButton.setToolTip("Supprimer toutes les données utilisateur")
        self.reinitButton.triggered.connect(self.reinit)

        self.about = QAction(QIcon("icons/about.png"), "À propos de")
        self.about.setStatusTip("En savoir plus sur ce programme.")
        self.about.setShortcut(QKeySequence("Ctrl+A"))
        self.help.setToolTip("En savoir plus sur ce programme.")
        self.about.triggered.connect(self.A_propos_de)

# Bouton "bandes dessinées sauvegardées" :

        self.saved = QAction(QIcon("icons/saved.png"), "BD sauvegardées")
        self.saved.setStatusTip("Ouvrir une Bande Dessinée sauvegardée.")
        self.saved.setShortcut(QKeySequence("Ctrl+shift+O"))
        self.saved.triggered.connect(self.tabs_widget.savedComicsDialog)

# Barre des fichiers :

        self.setStatusBar(QStatusBar())
        self.menuFichier = self.menuBar().addMenu("&Fichier")
        self.menuFichier.addAction(self.ouvrir)
        self.menuFichier.addAction(self.biblio)
        self.menuFichier.addAction(self.saved)
        self.menuFichier.addSeparator()
        self.menuFichier.addAction(self.quit)

# Barre "Partager" :

        self.menuShare = self.menuBar().addMenu("&Partager")
        self.menuShare.addAction(self.shareTweet)
        self.menuShare.addAction(self.shareFace)

# Barre "Actions" :

        self.menuActions = self.menuBar().addMenu("&Actions")
        self.menuActions.addAction(self.deleteButton)
        self.menuActions.addAction(self.reinitButton)

# Barre "Plus" :

        self.menuAide = self.menuBar().addMenu("&Plus")
        self.menuAide.addAction(self.help)
        self.menuAide.addAction(self.about)

# Barre d'outils :

        self.toolbar.addAction(self.ouvrir)
        self.toolbar.addAction(self.biblio)
        self.toolbar.addAction(self.saved)
        self.toolbar.addAction(self.help)
        self.toolbar.addAction(self.shareTweet)
        self.toolbar.addAction(self.shareFace)

        self.widget=QWidget()
        self.widget.setLayout(self.layout)
        self.setCentralWidget(self.widget)

        self.setCentralWidget(self.tabs_widget)
        
        self.show()

# Fonction du bouton d'aide :

    def Aide(self):
        self.popupHelp = QMessageBox(QMessageBox.Question,"Aide ","Aide :")
        self.popupHelp.setInformativeText("\nInformations : \n\nCe programme a été conçu pour lire et afficher\
 des bandes dessinées (fichiers .cbz et .cbr).\nPour l'utiliser, appuyez sur Ouvrir (Ctrl+O) et choisissez\
 un fichier .cbz ou .cbr.\n\n\n⚠ Attention ⚠ : \n\nLes fichiers .cbr ne fonctionnent pas correctement, la\
 fonctionnalité a donc été désactivée.\n\n\nRaccourcis :\n\nOuvrir une B.D. : Ctrl+O\nPage suiv. : Bouton droite (>) ou espace\nPage préc.\
 : Bouton gauche (<)\nMettre un marque-page : Ctrl+B\nZoomer : Ctrl++\nDézoomer : Ctrl+-\
 \nOuvrir une B.D. sauvegardée : Ctrl+Shift+O\nSupprimer une B.D. sauvegardée : Ctrl+Shift+S\
 \nOuvrir la bibliothèque : Ctrl+L\nNotice : Ctrl+N\nÀ propos de : Ctrl+A\nPartager sur Twitter : Ctrl+Shift+T\
 \nPartager sur Facebook : Ctrl+Shift+F\nQuitter : Crtl+Q")
        self.popupHelp.show()

# Fonction du bouton "À propos" :

    def A_propos_de(self):
        self.popupAbout = QMessageBox(QMessageBox.Information,"À propos de ","À propos :")
        self.popupAbout.setInformativeText("Ce logiciel a été crée et développé par DOPAGNE Jacques.\
 \n\nIl permet de lire les Bandes Dessinées, d'ajouter et d'étider ses métadonnées.\
 \n\nCréé en 2020 dans le cadre du projet final du cours d'IHM à l'ESME Sudria sous la direction du Dr. DAKKAR Borhen Eddine.\n")
        self.popupAbout.show()

# Fonction du bouton de partage sur Twitter :

    def shareTwitter(self,event):
        message = "Je suis en train d'utiliser la visionneuse de bandes dessinées du groupe DOPAGNE - LEVI et elle fonctionne à merveille ! #BandesDessinées #Comics #ComicsViewer"
        webbrowser.open("https://twitter.com/intent/tweet?text="+message)

# Fonction du bouton de partage sur Facebook :

    def shareFacebook(self):
        webbrowser.open("https://www.facebook.com/share.php?u=esme.fr&quote=Je+suis+en+train+d'utiliser+la+visionneuse+de+bandes+dessinées+du+groupe+DOPAGNE+-+LEVI+et+elle+fonctionne+à+merveille+!")

# Fonction du dialogue de suppression de bande dessinée enregistrée :

    def plsDELET(self):
        self.savedDialog = QDialog()
        self.savedDialog.setWindowTitle("Bandes Dessinées sauvegardées")
        self.savedDialog.setFixedSize(410, 130)
        savedComicsdir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/SavedComics"
        self.ExplText = QLabel("Sélectionnez une Bande Dessinée que vous souhaitez supprimer :",self.savedDialog)
        self.ExplText.move(10,15)
        if os.path.exists(savedComicsdir):
            comboBox = QComboBox(self.savedDialog)
            comboBox.setFixedWidth(370)
            self.savedFolderlist = next(os.walk(savedComicsdir))[-1]
            comboBox.addItems(self.savedFolderlist)
            comboBox.activated.connect(self.deleteSaved)
            comboBox.move(10,50)
        else:
            self.ExplText = QLabel("Aucune Bande Dessinée n'a été sauvegardée.",self.savedDialog)
            self.ExplText.move(10,55)
    
        boutonAnnuler = QPushButton("Annuler",self.savedDialog)
        boutonAnnuler.move(315,90)
        boutonAnnuler.clicked.connect(self.closeIt)
        
        self.savedDialog.exec_()

# Fonction de fermeture du dialogue de suppression de bande dessinée enregistrée :

    def closeIt(self):
        self.savedDialog.close()

# Fonction de suppression de bande dessinée enregistrée avec mise à jour des métadonnées liées :

    def deleteSaved(self, sel):
        savedComicsdir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/SavedComics"
        savedComicdir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/SavedComics/"+self.savedFolderlist[sel]
        os.remove(savedComicdir)
        self.permfiledir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/perm"
        with open(self.permfiledir+"/"+self.savedFolderlist[sel][:-4]+"/"+"metadata.txt", 'r') as f:
            s = f.read()
            self.old_data = ast.literal_eval(s)
        cover = self.old_data.get('cover')
        author = self.old_data.get('author')
        year = self.old_data.get('year')
        title = self.old_data.get('title')
        tags = self.old_data.get('tags')
        quality = self.old_data.get('quality')
        bookmarks = self.old_data.get('bookmarks')
        saved = "Non"
        self._metadata = {"cover":cover, "title": title, "author":author, "year":year, "tags":tags, "quality":quality, "saved":saved, "bookmarks":bookmarks}

        metadatadir = cover.rsplit('/', 1)[0]
        self.savedFolderlist = next(os.walk(savedComicsdir))[-1]
        if len(self.savedFolderlist) == 0:
            os.rmdir(savedComicsdir)
        f = open(metadatadir+"/"+"metadata.txt","w")
        f.write( str(self._metadata) )
        f.close()
        self.savedDialog.close()

# Fonction de réinitialisation des données de l'application :

    def reinit(self):
        msgBox = QMessageBox(self)
        reply = msgBox.question(
           self, "Réinitialiserl'application",
           ("Êtes-vous sûr de vouloir réinitialiser les données de l'application ?\n\nCes\
données seront irrécupérables et l'application redémarrera après la réinitialisation."),
           QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        userfilesdir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles"
        if reply == QMessageBox.Yes:
            shutil.rmtree(userfilesdir, ignore_errors=True)
            app.closeAllWindows()

# Fonction de fermeture de l'application :

    def closeEvent(self,event):
        shutil.rmtree(self.filedir, ignore_errors=True)
        app.closeAllWindows()
        event.accept()

# WIDGET DE VISUALISATION DE BANDE DESSINÉE (OUVERT POUR CHAQUE ONGLET DE BANDE DESSINÉE) :

class COMICWidget(QWidget):
    def __init__(self, pages, comicname, parent=None):
        super().__init__(parent)

        self.filedir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/temp"
        self.permfiledir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/perm"

        self.comicname = comicname
        self.pages = pages

# Ouverture des métadonnées liées à la bande dessinée pour voir les pages avec marque-pages :

        with open(self.permfiledir+"/"+self.comicname+"/"+"metadata.txt", 'r') as f:
            s = f.read()
            self.data = ast.literal_eval(s)
        self.bookmarks = self.data.get('bookmarks')

# Mise en place de l'affichage de l'image en visualisation, de la barre latérale,
# des boutons du widget de visualisation et de leurs raccourcis :

# Bouton "Page suivante" :

        self.layout = QGridLayout(self)
        self.nextpagebutton = QPushButton(self)
        self.nextpagebutton.setIcon(QIcon("icons/right.png"))
        self.nextpagebutton.setIconSize(QSize(40,40))
        self.nextpagebutton.setFixedSize(40, 700)
        self.nextpagebutton.setFlat(True)
        self.nextpagebutton.setEnabled(True)
        self.layout.addWidget(self.nextpagebutton, 0, 3)
        self.nextpagebutton.clicked.connect(self.readnext)

        for sequence in ("space", "right",):
            shorcut = QShortcut(sequence, self.nextpagebutton)
            shorcut.activated.connect(self.nextpagebutton.animateClick)

# Bouton "Page précédente" :

        self.prevpagebutton = QPushButton(self)
        self.prevpagebutton.setIcon(QIcon("icons/left.png"))
        self.prevpagebutton.setIconSize(QSize(40,40))
        self.prevpagebutton.setFixedSize(40, 700)
        self.prevpagebutton.setFlat(True)
        self.prevpagebutton.setEnabled(False)
        self.prevpagebutton.setShortcut("left")
        self.layout.addWidget(self.prevpagebutton, 0, 1)
        self.prevpagebutton.clicked.connect(self.readprev)

# Bouton "Marquer la page" :

        self.bookmarkButton = QPushButton(self)
        self.bookmarkButton.setIcon(QIcon("icons/bookmark.png"))
        self.bookmarkButton.setIconSize(QSize(20,20))
        self.bookmarkButton.setFixedSize(20, 20)
        self.bookmarkButton.setFlat(True)
        self.bookmarkButton.setShortcut("Ctrl+B")
        self.layout.addWidget(self.bookmarkButton, 1, 0)
        self.bookmarkButton.clicked.connect(self.bookmarkIt)

# Affichage du numéro de page :

        self.pageNumDisp = QLabel()
        self.pageNumDisp.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(self.pageNumDisp, 1, 2)

# QStackedLayout pour l'affichage des images de la bande dessinée :

        self.page_viewer = QStackedLayout()
        self.layout.addLayout(self.page_viewer, 0, 2)

# Bouton "Zoomer" :

        self.zoomInbutton = QPushButton(self)
        self.zoomInbutton.setIcon(QIcon("icons/zoomin.png"))
        self.zoomInbutton.setIconSize(QSize(20,20))
        self.zoomInbutton.setFixedSize(20, 20)
        self.zoomInbutton.setFlat(True)
        self.zoomInbutton.setShortcut("Ctrl++")
        self.layout.addWidget(self.zoomInbutton, 1, 1)
        self.zoomInbutton.clicked.connect(self.zoomIn)

# Bouton "Dézoomer" :

        self.zoomOutbutton = QPushButton(self)
        self.zoomOutbutton.setIcon(QIcon("icons/zoomout.png"))
        self.zoomOutbutton.setIconSize(QSize(20,20))
        self.zoomOutbutton.setFixedSize(20, 20)
        self.zoomOutbutton.setFlat(True)
        self.zoomOutbutton.setShortcut("Ctrl+-")
        self.layout.addWidget(self.zoomOutbutton, 1, 2)
        self.zoomOutbutton.clicked.connect(self.zoomOut)

# Barre latérale :

        self.pagescroller = QScrollArea()
        self.buttonslay = QVBoxLayout()
        self.buttonslay.setSpacing(0)
        self.pagescroller.setFixedWidth(200)
        self.pagescroller.setLayout(self.buttonslay)
        self.pagescroller.setWidgetResizable(True)
        self.pagescroller.setStyleSheet('QScrollArea {background-color: #34495E}')
        
        self.inner = QFrame(self.pagescroller)
        self.inner.setLayout(QVBoxLayout())
        self.pagescroller.setWidget(self.inner)
        self.inner.layout().setAlignment(Qt.AlignCenter)

# Boutons avec image de la barre latérale :

        self.buttons = {}

        count = 0
        for i in self.pages:
            self.buttons[i] = QPushButton()
            self.buttons[i].setObjectName(str(count+1))
            icon  = QPixmap(self.filedir+"/"+str(i))
            if int(icon.width()) == 0:
                self.q = 1
            elif int(icon.width()) != 0:
                self.q = int(icon.width())
            self.scaleFactor = (155/self.q)
            self.picSize = self.scaleFactor * icon.size()
            icon = icon.scaled(self.picSize)
            self.buttons[i].setFixedSize(160, icon.height())
            palette = QPalette()
            palette.setBrush(self.buttons[i].backgroundRole(), QBrush(icon))
            self.buttons[i].setPalette(palette)
            self.buttons[i].setAutoFillBackground(True)
            self.buttons[i].setFlat(True)
            self.inner.layout().setSpacing(0)
            self.inner.layout().addWidget(self.buttons[i])
            self.buttons[i].clicked.connect(self.showButtonPage)
            count += 1

        self.layout.addWidget(self.pagescroller, 0, 0)

# Chargement de toutes les images de la bande dessinée :

        for n in self.pages:
            mainWindow = FenetrePrincipale()
            width = mainWindow.frameGeometry().width()
            viewerWidth = width*0.75
            self.page = QLabel()
            self.page.setPixmap(QPixmap(self.filedir+"/"+str(n)))
            self.page.setScaledContents(True)
            self.page.repaint()
            self.scroller = QScrollArea()
            if int(self.page.pixmap().width()) == 0:
                self.k = 1
            elif int(self.page.pixmap().width()) != 0:
                self.k = int(self.page.pixmap().width())
            self.scaleFactor = (viewerWidth/self.k)
            self.picSize = self.scaleFactor * self.page.pixmap().size()
            self.page.setFixedSize(self.picSize)

            self.scroller.setWidget(self.page)
            self.scroller.setWidgetResizable(True)
            self.page_viewer.addWidget(self.scroller)

        self.page_viewer.currentChanged.connect(self.page_changed)
        self.page_changed(0)

# Fonction pour l'affichage du numéro de la page (en bas) :

    def page_changed(self, page_nr):
        for bookmark in self.bookmarks:
            if page_nr == int(bookmark):
                self.bookmarkedNotif()
        self.pageNumDisp.setText("Page : "+str(page_nr+1)+" sur "+str(self.page_count()))

# fonction de comptage des pages :

    def page_count(self):
        return self.page_viewer.count()

# Fonction de page actuelle :

    def current_page(self):
        return self.page_viewer.currentIndex()

# Fonction montrant la page appuyée dans la barre latérale :

    def showButtonPage(self):
        new_page = int(self.sender().objectName())
        if int(new_page)-1 == self.page_count()-1:
            self.nextpagebutton.setEnabled(False)
        if int(new_page)-1 != 0:
            self.prevpagebutton.setEnabled(True)
        if int(new_page)-1 != self.page_count()-1:
            self.nextpagebutton.setEnabled(True)
        if int(new_page)-1 == 0:
            self.prevpagebutton.setEnabled(False)
        self.page_viewer.setCurrentIndex(int(new_page)-1)

# Fonction pour lire la page suivante :

    def readnext(self):
        new_page  = min(self.current_page() + 1, self.page_count()-1)
        if new_page == self.page_count()-1:
            self.nextpagebutton.setEnabled(False)
        if new_page != 0:
            self.prevpagebutton.setEnabled(True)
        self.page_viewer.setCurrentIndex(new_page)

# Fonction pour lire la page précédente :

    def readprev(self):
        new_page = max(self.current_page() - 1, 0)
        if new_page != self.page_count()-1:
            self.nextpagebutton.setEnabled(True)
        if new_page == 0:
            self.prevpagebutton.setEnabled(False)
        self.page_viewer.setCurrentIndex(new_page)

# Fonction pour zoomer (sur un popup) :

    def zoomIn(self):
        self.zoomInDialog = QDialog()
        mainWindow = FenetrePrincipale()
        actual_page = self.current_page()
        
        width = mainWindow.frameGeometry().width()
        viewerWidth = width*0.9
        height = mainWindow.frameGeometry().height()
        viewerHeight = height*0.95
        self.zoomInDialog.setWindowTitle("Image zoomée")
        self.zoomInDialog.setFixedSize(viewerWidth, viewerHeight)
        page = QLabel()
        page.setPixmap(QPixmap(self.filedir+"/"+self.pages[actual_page]))
        page.setScaledContents(True)
        scroller = QScrollArea(self.zoomInDialog)
        if int(page.pixmap().width()) == 0:
            k = 1
        elif int(page.pixmap().width()) != 0:
            k = int(page.pixmap().width())
        scaleFactor = (viewerWidth/k)*2
        picSize = scaleFactor * page.pixmap().size()
        page.setFixedSize(picSize)
        scroller.setFixedSize(viewerWidth-30, viewerHeight-30)
        scroller.move(15,15)
        scroller.setStyleSheet('QScrollArea {background-color: transparent}')

        scroller.setWidget(page)
        scroller.setWidgetResizable(False)
        
        self.zoomInDialog.exec_()

# Fonction pour dézoomer (sur un popup) :

    def zoomOut(self):
        self.zoomOutDialog = QDialog()
        mainWindow = FenetrePrincipale()
        actual_page = self.current_page()
        
        width = mainWindow.frameGeometry().width()
        viewerWidth = width*0.9
        height = mainWindow.frameGeometry().height()
        viewerHeight = height*0.9
        self.zoomOutDialog.setWindowTitle("Image dézoomée")
        page = QLabel()
        page.setPixmap(QPixmap(self.filedir+"/"+self.pages[actual_page]))
        page.setScaledContents(True)
        scroller = QScrollArea(self.zoomOutDialog)
        if int(page.pixmap().width()) == 0:
            k = 1
        elif int(page.pixmap().width()) != 0:
            k = int(page.pixmap().width())
        scaleFactor = (viewerWidth/k)*0.4
        self.zoomOutDialog.setFixedSize(scaleFactor*page.pixmap().width()+30, viewerHeight)
        picSize = scaleFactor * page.pixmap().size()
        page.setFixedSize(picSize)
        scroller.setFixedSize(scaleFactor*page.pixmap().width(), viewerHeight-30)
        scroller.move(15,15)
        scroller.setStyleSheet('QScrollArea {background-color: transparent}')

        scroller.setWidget(page)
        scroller.setWidgetResizable(False)
        
        self.zoomOutDialog.exec_()

# Fonction pour marquer une page et mise à jour des métadonnées concernées :

    def bookmarkIt(self):
        actual_page = self.current_page()
        bookmarkDic = dict.fromkeys(self.bookmarks , 1)
        if str(actual_page) in bookmarkDic:
            alreadyBookmarkedMsg = QMessageBox()
            alreadyBookmarkedMsg.setIcon(QMessageBox.Information)
            alreadyBookmarkedMsg.setText("Page déjà marquée :")
            alreadyBookmarkedMsg.setInformativeText("Cette page a déjà été marquée.\nVous pouvez modifier vos marque-pages via la bibliothèque.")
            alreadyBookmarkedMsg.setWindowTitle("Visionneuse de BD")
            alreadyBookmarkedMsg.exec_()
        else:
            with open(self.permfiledir+"/"+self.comicname+"/"+"metadata.txt", 'r') as f:
                s = f.read()
                self.old_data = ast.literal_eval(s)
            cover = self.old_data.get('cover')
            author = self.old_data.get('author')
            year = self.old_data.get('year')
            title = self.old_data.get('title')
            tags = self.old_data.get('tags')
            quality = self.old_data.get('quality')
            saved = self.old_data.get('saved')
            bookmarksList = self.old_data.get('bookmarks')
            bookmarksList.append(str(actual_page))
            bookmarks = bookmarksList
            self._metadata = {"cover":cover, "title": title, "author":author, "year":year, "tags":tags, "quality":quality, "saved":saved, "bookmarks":bookmarks}
            
            metadatadir = cover.rsplit('/', 1)[0]
            f = open(metadatadir+"/"+"metadata.txt","w")
            f.write( str(self._metadata) )
            f.close()
            bookmarkAddedMsg = QMessageBox()
            bookmarkAddedMsg.setIcon(QMessageBox.Information)
            bookmarkAddedMsg.setText("Marque-page ajouté :")
            bookmarkAddedMsg.setInformativeText("Votre marque-page a été ajouté.\nVous aurez une notification sur cette page les prochaines fois que vous ouvrirez cette BD.\nVous pouvez modifier vos marque-pages via la bibliothèque.")
            bookmarkAddedMsg.setWindowTitle("Visionneuse de BD")
            bookmarkAddedMsg.exec_()

# Fonction pour notifier l'utilisateur que la page sur laquelle il est est marquée :

    def bookmarkedNotif(self):
        bookmarkedMsg = QMessageBox()
        bookmarkedMsg.setIcon(QMessageBox.Information)
        bookmarkedMsg.setText("Page marquée :")
        bookmarkedMsg.setInformativeText("La page actuelle est marquée.\nVous pouvez modifier vos marque-pages via la bibliothèque.")
        bookmarkedMsg.setWindowTitle("Visionneuse de BD")
        bookmarkedMsg.exec_()

# WIDGET DE LA BIBLIOTHÈQUE :

class BiblioWidget(QWidget):
    def __init__(self, parent=None):
        super(QWidget, self).__init__(parent)
        
        self.permfiledir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/perm"

# Listage et comptage des dossiers dans le dossier "UserFiles/perm" :

        self.folderlist = next(os.walk(self.permfiledir))[1]
        self.foldercount = len(self.folderlist)
        
        self.layout = QGridLayout(self)

# Réglage de l'affichage de la bibliothèque :

        mainWindow = FenetrePrincipale()
        width = mainWindow.frameGeometry().width()
        viewerWidth = width*0.94444444

        self.scroller = QScrollArea()
        self.scroller.setStyleSheet('QScrollArea {background-color: #34495E}')
        self.scroller.setFixedSize(viewerWidth, 720)
        self.scroller.setWidgetResizable(True)

# Réglage de l'affichage des lignes/colonnes du tableau de la bibliothèque :

        self.table = QTableWidget()
        self.table.verticalHeader().setVisible(False)
        self.table.setRowCount(self.foldercount)
        self.table.setColumnCount(10)
        self.table.setHorizontalHeaderLabels(("Couverture", "Titre", "Auteur", "Année", "Tags", "Qualité", "Marque-pages", "Sauvegardé", "Modifier", "Supprimer"))

# Message pour bibliothèque vide :

        if self.foldercount == 0:
            noComicOpenedMsg = QMessageBox()
            noComicOpenedMsg.setIcon(QMessageBox.Information)
            noComicOpenedMsg.setText("Ouvrez une Bande Dessinée :")
            noComicOpenedMsg.setInformativeText("Bienvenue à la Bibliothèque !\nOuvrez une bande dessinée afin de générer ses métadonnées et les modifier.")
            noComicOpenedMsg.setWindowTitle("Bibliothèque")
            noComicOpenedMsg.exec_()

# Réglage de l'affichage du tableau de la bibliothèque :

        self.table.move(0,0)

        header = self.table.horizontalHeader()
        for i in range(2, 10):
            header.setSectionResizeMode(i, QHeaderView.Stretch)
            self.table.setRowHeight(i, 225)
        for i in (0, 1, 5):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)
            self.table.setRowHeight(i, 225)

# Affichage du tableau de la bibliothèque :

        count = 0
        for i in self.folderlist:
            with open(self.permfiledir+"/"+i+"/"+"metadata.txt", 'r') as f:
                s = f.read()
                self.data = ast.literal_eval(s)
            
            # Image de couverture :
            
            self.coverImage = QLabel()
            self.coverImage.setPixmap(QPixmap(self.data.get('cover')))
            self.coverImage.setScaledContents(True)
            if int(self.coverImage.pixmap().width()) == 0:
                self.k = 1
            elif int(self.coverImage.pixmap().width()) != 0:
                self.k = int(self.coverImage.pixmap().width())
            self.scaleFactor = (145/self.k)
            self.picSize = self.scaleFactor * self.coverImage.pixmap().size()
            self.coverImage.setFixedSize(self.picSize)
            cell_widget = QWidget()
            lay_out = QHBoxLayout(cell_widget)
            lay_out.addWidget(self.coverImage)
            lay_out.setAlignment(Qt.AlignCenter)
            lay_out.setContentsMargins(0,0,0,0)
            cell_widget.setLayout(lay_out)
            self.table.setCellWidget(count, 0, cell_widget)

            # Titre :
            
            self.table.setItem(count, 1, QTableWidgetItem(self.data.get('title')))
        
            # Auteur :
            
            self.table.setItem(count, 2, QTableWidgetItem(self.data.get('author')))
        
            # Année :
            
            self.table.setItem(count, 3, QTableWidgetItem(self.data.get('year')))
        
            # Tags :
            
            if len(self.data.get('tags')) == 0:
                self.table.setItem(count, 4, QTableWidgetItem("Aucun tag"))
            else:
                self.table.setItem(count, 4, QTableWidgetItem(str(', '.join(self.data.get('tags')))))
        
            # Qualité (images avec indice recherche gta):
            
            self.qualityImage = QLabel()
            if str(self.data.get('quality')) == "0":
                self.qualityImage.setPixmap(QPixmap(os.path.dirname(os.path.abspath(__file__))+"/icons/gta5-0stars.png"))
            elif str(self.data.get('quality')) == "1":
                self.qualityImage.setPixmap(QPixmap(os.path.dirname(os.path.abspath(__file__))+"/icons/gta5-1stars.png"))
            elif str(self.data.get('quality')) == "2":
                self.qualityImage.setPixmap(QPixmap(os.path.dirname(os.path.abspath(__file__))+"/icons/gta5-2stars.png"))
            elif str(self.data.get('quality')) == "3":
                self.qualityImage.setPixmap(QPixmap(os.path.dirname(os.path.abspath(__file__))+"/icons/gta5-3stars.png"))
            elif str(self.data.get('quality')) == "4":
                self.qualityImage.setPixmap(QPixmap(os.path.dirname(os.path.abspath(__file__))+"/icons/gta5-4stars.png"))
            elif str(self.data.get('quality')) == "5":
                self.qualityImage.setPixmap(QPixmap(os.path.dirname(os.path.abspath(__file__))+"/icons/gtasa-5stars.png"))
            self.qualityImage.setScaledContents(True)
            if int(self.qualityImage.pixmap().width()) == 0:
                self.k = 1
            elif int(self.qualityImage.pixmap().width()) != 0:
                self.k = int(self.qualityImage.pixmap().width())
            self.scaleFactor = (175/self.k)
            self.qualityImage.setAlignment(Qt.AlignCenter)
            self.picSize = self.scaleFactor * self.qualityImage.pixmap().size()
            self.qualityImage.setFixedSize(self.picSize)
            cell_widget2 = QWidget()
            lay_out2 = QHBoxLayout(cell_widget2)
            lay_out2.addWidget(self.qualityImage)
            lay_out2.setAlignment(Qt.AlignCenter)
            lay_out2.setContentsMargins(0,0,0,0)
            cell_widget2.setLayout(lay_out2)
            self.table.setCellWidget(count, 5, cell_widget2)
            
            # Marque-pages :
            
            bookList = self.data.get('bookmarks')
            newBookList = []
            for bookmark in bookList:
                bookmark = str(int(bookmark)+1)
                newBookList.append(bookmark)
            if len(newBookList) == 0:
                self.table.setItem(count, 6, QTableWidgetItem("Aucune page"))
            elif len(newBookList) == 1:
                self.table.setItem(count, 6, QTableWidgetItem("Page "+str(', '.join(newBookList))))
            else:
                self.table.setItem(count, 6, QTableWidgetItem("Pages "+str(', '.join(newBookList))))
            
            # Sauvegardé Y/N :
            
            self.table.setItem(count, 7, QTableWidgetItem(self.data.get('saved')))
            
            # Modifier :
            
            self.boutonModifier = {}
            for n in range(self.foldercount):
                self.boutonModifier[n] = QPushButton("Modifier", objectName=str(i))
                self.table.setCellWidget(count, 8, self.boutonModifier[n])
                self.boutonModifier[n].clicked.connect(self.updateData)
            
            # Supprimer :
            
            self.boutonSupprimer = {}
            for n in range(self.foldercount):
                self.boutonSupprimer[n] = QPushButton("Supprimer", objectName=str(i))
                self.table.setCellWidget(count, 9, self.boutonSupprimer[n])
                self.boutonSupprimer[n].clicked.connect(self.deleteComic)
            
            count += 1
        
        self.scroller.setWidget(self.table)
        
        self.layout.addWidget(self.scroller, 0, 0)

# Page de dialogue pour la modification des métadonnées, affichage des données
# par défaut dans les lignes de saisie :

    def updateData(self):
        self.dialog = QDialog()
        self.dialog.setWindowTitle("Modifier les métadonnées")
        self.actualfiledir = self.permfiledir+"/"+str(self.sender().objectName())+"/metadata.txt"
        with open(self.actualfiledir, 'r') as f:
                s = f.read()
                self.old_data = ast.literal_eval(s)
        self.dialog.setFixedSize(500, 535)

        # Message d'explication :
        
        self.ExplText = QLabel("Vous pouvez modifier les données en remplaçant\
 le texte dans les cases.\n\nSéparez les tags et les marque-pages avec des espaces.",self.dialog)
        self.ExplText.move(10,15)


        # Bouton "Terminé" :
        
        self.boutonTermine = QPushButton("Terminé",self.dialog)
        self.boutonTermine.move(400,500)
        self.boutonTermine.clicked.connect(self.okClicked)
        
        # Bouton "Annuler" :
        
        self.boutonAnnuler = QPushButton("Annuler",self.dialog)
        self.boutonAnnuler.move(310,500)
        self.boutonAnnuler.clicked.connect(self.closeIt)
        
        # Modification du titre :
        
        self.titleText = QLabel("Titre :",self.dialog)
        self.titleLine = QLineEdit(self.old_data.get('title'), self.dialog)
        self.titleLine.setFixedWidth(480)
        self.titleText.move(10,80)
        self.titleLine.move(10,100)
        
        # Modification de l'auteur :
        
        self.authorText = QLabel("Auteur :",self.dialog)
        self.authorLine = QLineEdit(self.old_data.get('author'), self.dialog)
        self.authorLine.setFixedWidth(480)
        self.authorText.move(10,140)
        self.authorLine.move(10,160)
        
        # Modification de l'année :
        
        self.yearText = QLabel("Année :",self.dialog)
        self.yearLine = QLineEdit(self.old_data.get('year'), self.dialog)
        self.yearLine.setValidator(QIntValidator(0, 3000))
        self.yearLine.setFixedWidth(480)
        self.yearText.move(10,200)
        self.yearLine.move(10,220)
        
        # Modification des tags :
        
        self.tagsText = QLabel("Tags :",self.dialog)
        self.tagsLine = QTextEdit(str(' '.join(self.old_data.get('tags'))), self.dialog)
        self.tagsLine.setFixedSize(480, 80)
        self.tagsText.move(10,260)
        self.tagsLine.move(10,280)
        
        # Modification de la qualité :
        
        self.qualityText = QLabel("Qualité :",self.dialog)
        self.qualityLine = QLineEdit(str(self.old_data.get('quality')), self.dialog)
        self.qualityLine.setValidator(QIntValidator(0, 5))
        self.qualityLine.setFixedWidth(480)
        self.qualityText.move(10,370)
        self.qualityLine.move(10,400)
        
        # Modification des marque-pages :
        
        bookList = self.old_data.get('bookmarks')
        newBookList = []
        for bookmark in bookList:
            bookmark = str(int(bookmark)+1)
            newBookList.append(bookmark)
        self.bookmarksText = QLabel("Marque-pages :",self.dialog)
        self.bookmarksLine = QLineEdit(str(' '.join(newBookList)), self.dialog)
        self.bookmarksLine.setFixedWidth(480)
        self.bookmarksText.move(10,435)
        self.bookmarksLine.move(10,465)

        self.dialog.exec_()

# Fonction d'enregistrement des modifications sur les métadonnées, messages éventuels
# d'erreur, reprise des anciennes données pour les lignes non modifiées, message de
# demande de redémarrage de la bibliothèque pour voir les modifications :

    def okClicked(self):
        cover = self.old_data.get('cover')
        author = self.authorLine.text()
        year = self.yearLine.text()
        title = self.titleLine.text()
        tagslist = self.tagsLine.toPlainText().split()
        tags = tagslist
        quality = self.qualityLine.text()
        
        bookmarkslist = self.bookmarksLine.text().split()
        newBookList = []
        for bookmark in bookmarkslist:
            bookmark = str(int(bookmark)-1)
            newBookList.append(bookmark)
        for bookmark in bookmarkslist:
            if bookmark.isdecimal() is False:
                bookmarks = self.old_data.get('bookmarks')
                wrongCharacterMsg = QMessageBox()
                wrongCharacterMsg.setIcon(QMessageBox.Information)
                wrongCharacterMsg.setText("Erreur :")
                wrongCharacterMsg.setInformativeText("Vous ne devez entrer que des\
 chiffres séparés d'espaces dans les marque-pages. Aucune modification n'a été apportée sur les marque-pages.")
                wrongCharacterMsg.setWindowTitle("Bibliothèque")
                wrongCharacterMsg.exec_()
            else:
                bookmarks = newBookList
        if self.bookmarksLine.text() == "":
            bookmarks = []
        saved = self.old_data.get('saved')
        self._metadata = {"cover":cover, "title": title, "author":author, "year":year, "tags":tags, "quality":quality, "saved":saved, "bookmarks":bookmarks}
        
        metadatadir = cover.rsplit('/', 1)[0]
        
        f = open(metadatadir+"/"+"metadata.txt","w")
        f.write( str(self._metadata) )
        f.close()
        
        restartMsg = QMessageBox()
        restartMsg.setIcon(QMessageBox.Information)
        restartMsg.setText("Relancer la bibliothèque :")
        restartMsg.setInformativeText("Veuillez relancer la bibliothèque pour voir les modifications.")
        restartMsg.setWindowTitle("Bibliothèque")
        restartMsg.exec_()

        self.dialog.close()

# Fonction de suppression des données d'une bande dessinée :

    def deleteComic(self):
        shutil.rmtree(self.permfiledir+"/"+str(self.sender().objectName()), ignore_errors=True)
        restartMsg = QMessageBox()
        restartMsg.setIcon(QMessageBox.Information)
        restartMsg.setText("Relancer la bibliothèque :")
        restartMsg.setInformativeText("Veuillez relancer la bibliothèque pour voir les modifications.")
        restartMsg.setWindowTitle("Bibliothèque")
        restartMsg.exec_()

# Fonction de fermeture du dialogue de mofification des métadonnées :

    def closeIt(self): 
        self.dialog.close()

# Fonction de fermeture du dialogue de suppression des métadonnées d'une bande dessinée :

    def closeIt2(self): 
        self.delYesNo.close()

# WIDGET D'OUVERTURE DES BANDES DESSINÉES ET DE GESTION DES ONGLETS :

class TabsWidget(QWidget):
    def __init__(self, parent=None):
        super(QWidget, self).__init__(parent)

# Mise en place des variables et de l'affichage du widget :

        self.layout = QGridLayout()

        self.filedir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/temp"
        self.permfiledir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/perm"

        self.LibOpened = 0
        self.saving = {}

        self._metadata = {}

# Création du dossier UserFiles et UserFiles/perm s'ils n'existent pas :

        if not os.path.exists(self.permfiledir):
            os.makedirs(self.permfiledir)

# Création du widget des onglets :

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setMovable(True)
        self.tabs.setTabsClosable(True)

        self.tabs.elideMode()
        self.tabs.setElideMode(2)
        self.tabs.setIconSize(QSize(16, 16))

        self.tabs.tabCloseRequested.connect(self.removeTab)

        self.layout.addWidget(self.tabs, 0, 0)
        self.setLayout(self.layout)

# Fonction d'affichage de la fenêtre de dialogue pour ouvrir des bandes dessinées enregistrées :

    def savedComicsDialog(self):
        self.savedDialog = QDialog()
        self.savedDialog.setWindowTitle("Bandes Dessinées sauvegardées")
        self.savedDialog.setFixedSize(390, 130)
        savedComicsdir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/SavedComics"
        self.ExplText = QLabel("Sélectionnez une Bande Dessinée que vous souhaitez ouvrir :",self.savedDialog)
        self.ExplText.move(10,15)
        if os.path.exists(savedComicsdir):
            comboBox = QComboBox(self.savedDialog)
            comboBox.setFixedWidth(370)
            self.savedFolderlist = next(os.walk(savedComicsdir))[-1]
            comboBox.addItems(self.savedFolderlist)
            comboBox.activated.connect(self.openSaved)
            comboBox.move(10,50)
        else:
            self.ExplText = QLabel("Aucune Bande Dessinée n'a été sauvegardée.",self.savedDialog)
            self.ExplText.move(10,55)

        boutonAnnuler = QPushButton("Annuler",self.savedDialog)
        boutonAnnuler.move(295,90)
        boutonAnnuler.clicked.connect(self.closeIt)

        self.savedDialog.exec_()

# Fonction de fermeture du dialogue d'ouverture de bandes dessinées enregistrées :

    def closeIt(self): 
        self.savedDialog.close()

# Fonction d'ouverture de bande dessinée, création systématique de métadonnées, 
# pour les premières ouvertures et bandes dessinées dont les métadonnées ont été
# supprimées, seul les fichiers .cbz fonctionnent (.cbr en """commentaire""" mais
# non optimisé pour les fonctionnalités du logiciel, message d'erreur), demande
# de sauvegarde si la bande dessinée n'est pas déjà sauvegardée, mise à jour des
# métadonnées si sauvegarde il y a, message demandant de redémarrer la bibliothèque
# si cette dernière a été ouverte (nouvel onglet) :

    def Ouvrir(self):
        charg = QFileDialog()
        self.chemin = charg.getOpenFileName(caption = 'Ouvrir la Bande Dessinée',filter='Fichier ZIP (*.cbz);;Fichier RAR (*.cbr)')
        self.filename = self.chemin[0]
        self.comicname = str(self.filename.rsplit("/", 1)[-1])[:-4]
        self.book_extension = Path(self.filename).suffix
        savedComicsdir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/SavedComics/"+str(self.filename.rsplit("/", 1)[-1])

        if self.filename :

            if self.book_extension == '.cbz':
                with zipfile.ZipFile(self.filename) as zf:
                    zf.extractall(self.filedir)
                self.book = zipfile.ZipFile(
                    self.filename, mode='r', allowZip64=True)
                self.image_list = [
                    i.filename for i in self.book.infolist()
                    if not i.is_dir() and is_image(i.filename)]
            if not os.path.exists(savedComicsdir):
                msgBox = QMessageBox(self)
                reply = msgBox.question(
                    self, "Ouvrir",
                    ("Voulez-vous sauvegarder le contenu de cette Bande Dessinée ?\n\nElle\
 sera désormais sauvegardée dans les fichiers du logiciel."),
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
                self.savedComicsdir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/SavedComics"
                if reply == QMessageBox.Yes:
                    if not os.path.exists(self.savedComicsdir):
                        os.makedirs(self.savedComicsdir)
                    copyfile(self.filename, self.savedComicsdir+"/"+self.comicname+".cbz")
                    metadatadir = self.permfiledir+"/"+self.comicname
                    currentmeta = pathlib.Path(metadatadir+"/"+"metadata.txt")
                    self.saving = 1
                    if currentmeta.exists():
                        with open(currentmeta, 'r') as f:
                            s = f.read()
                            self.old_data = ast.literal_eval(s)
                        cover = self.old_data.get('cover')
                        author = self.old_data.get('author')
                        year = self.old_data.get('year')
                        title = self.old_data.get('title')
                        tags = self.old_data.get('tags')
                        quality = self.old_data.get('quality')
                        bookmarks = self.old_data.get('bookmarks')
                        saved = "Oui"
                        self._metadata = {"cover":cover, "title": title, "author":author, "year":year, "tags":tags, "quality":quality, "saved":saved, "bookmarks":bookmarks}
                        
                        metadatadir = cover.rsplit('/', 1)[0]
                        f = open(metadatadir+"/"+"metadata.txt","w")
                        f.write( str(self._metadata) )
                        f.close()

            elif self.book_extension == '.cbr':
                errorMsg = QMessageBox()
                errorMsg.setIcon(QMessageBox.Critical)
                errorMsg.setFixedWidth(700)
                errorMsg.setDetailedText("Erreur No. 1.\nRéférez-vous aux développeurs pour plus d'informations.")
                errorMsg.setText("Fichier .cbr")
                errorMsg.setInformativeText("Le logiciel ne supporte pas encore les fichiers .rar.")
                errorMsg.setWindowTitle("Erreur Fatale No. 1")
                errorMsg.exec_()
                self.closeEvent()
                
                """Retourne [rarfile.RarUnknownError: Unknown exit code [1]: bsdtar: 
                    Unrecognized archive format] que l'on soit sur Mac ou Windows.
                
                with rarfile.RarFile(self.filename) as rf:
                    rf.extractall(self.filedir)
                self.book = rarfile.RarFile(self.filename)
                self.image_list = [
                    i.filename for i in self.book.infolist()
                    if not i.isdir() and is_image(i.filename)]"""

        if self.LibOpened == 1:
            restartMsg = QMessageBox()
            restartMsg.setIcon(QMessageBox.Information)
            restartMsg.setText("Relancer la bibliothèque :")
            restartMsg.setInformativeText("Veuillez relancer la bibliothèque pour y voir les modifications.")
            restartMsg.setWindowTitle("Bibliothèque")
            restartMsg.exec_()
            self.LibOpened = 0

        metadatadir = self.permfiledir+"/"+self.comicname
        currentmeta = pathlib.Path(metadatadir+"/"+"metadata.txt")
        if currentmeta.exists():
            widget = COMICWidget(self.image_list, self.comicname)
            self.tabs.addTab(widget, QIcon("icons/book.png"), self.comicname)
        else:
            self.generate_metadata()
            widget = COMICWidget(self.image_list, self.comicname)
            self.tabs.addTab(widget, QIcon("icons/book.png"), self.comicname)

# Fonction d'ouverture de bandes dessinées sauvegardées, fonction plus simple que
# la fonction d'ouverture originale (nouvel onglet) :

    def openSaved(self, sel):
        savedComicsdir = os.path.dirname(os.path.abspath(__file__))+"/UserFiles/SavedComics/"+self.savedFolderlist[sel]
        self.filename = self.savedFolderlist[sel]
        self.comicname = str(self.filename.rsplit("/", 1)[-1])[:-4]
        self.book_extension = Path(savedComicsdir).suffix
        if self.book_extension == '.cbz':
            with zipfile.ZipFile(savedComicsdir) as zf:
                zf.extractall(self.filedir)
            self.book = zipfile.ZipFile(
                savedComicsdir, mode='r', allowZip64=True)
            self.image_list = [
                i.filename for i in self.book.infolist()
                if not i.is_dir() and is_image(i.filename)]

        elif self.book_extension == '.cbr':
            errorMsg = QMessageBox()
            errorMsg.setIcon(QMessageBox.Critical)
            errorMsg.setFixedWidth(700)
            errorMsg.setDetailedText("Erreur No. 1.\nRéférez-vous aux développeurs pour plus d'informations.")
            errorMsg.setText("Fichier .cbr")
            errorMsg.setInformativeText("Le logiciel ne supporte pas encore les fichiers .rar.")
            errorMsg.setWindowTitle("Erreur No. 1")
            errorMsg.exec_()
            self.closeEvent()
        
        widget = COMICWidget(self.image_list, self.comicname)
        self.tabs.addTab(widget, QIcon("icons/book.png"), self.comicname)
        self.savedDialog.close()

# Fonction d'ouverture de la bibliothèque (nouvel onglet) :

    def Biblio(self):
        self.LibOpened = 1
        biblio_widget = BiblioWidget()
        self.tabs.addTab(biblio_widget, QIcon("icons/lib.png"), "Bibliothèque")

# Fonction de génération des métadonnées :

    def generate_metadata(self, author='<Unknown>', isbn = None, tags=[], quality=0):

        self.metadatadir = self.permfiledir+"/"+self.comicname

        if not os.path.exists(self.metadatadir):
            os.makedirs(self.metadatadir)
        title = self.comicname

        copyfile(self.filedir+"/"+self.image_list[0], self.metadatadir+"/"+self.image_list[0].rsplit('/', 1)[-1])
        cover = self.metadatadir+"/"+self.image_list[0].rsplit('/', 1)[-1]

        creation_time = time.ctime(os.path.getctime(self.filename))
        year = creation_time.split()[-1]

        bookmarks = []

        saved = "Non"
        if self.saving == 1:
            saved = "Oui"
            self.saving = 0

        self._metadata = {"cover":cover, "title": title, "author":author, "year":year, "tags":tags, "quality":quality, "saved":saved, "bookmarks":bookmarks}
        
        f = open(self.metadatadir+"/"+"metadata.txt","w")
        f.write( str(self._metadata) )
        f.close()
        return self._metadata

# Fonction de fermeture des onglets :

    def removeTab(self, index):
        widget = self.tabs.widget(index)
        if widget is not None:
            widget.deleteLater()
        self.tabs.removeTab(index)

# Fonction de validation de l'extension des images :

def is_image(filename):
    valid_image_extensions = ['.png', '.jpg', '.bmp']
    if os.path.splitext(filename)[1].lower() in valid_image_extensions:
        return True
    else:
        return False


# Lancement de l'application :
app = QCoreApplication.instance()
if app is None:
    app = QApplication(sys.argv)

window = FenetrePrincipale()
window.show()

app.exec_()
